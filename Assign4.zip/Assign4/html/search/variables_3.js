var searchData=
[
  ['led_5fstatus_28',['led_status',['../structRTDB.html#a534a52f9720fc348ff8107bdd28f94c1',1,'RTDB']]]
];
