var searchData=
[
  ['button_5fstatus_4',['button_status',['../structRTDB.html#a68fec7199aa39dc84d11340e709c39f2',1,'RTDB']]],
  ['button_5ftask_5',['button_task',['../task_8h.html#aacb2177e163e5153cbdad73883366b9c',1,'task.h']]]
];
