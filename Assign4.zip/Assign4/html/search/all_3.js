var searchData=
[
  ['led_5fstatus_7',['led_status',['../structRTDB.html#a534a52f9720fc348ff8107bdd28f94c1',1,'RTDB']]],
  ['led_5ftask_8',['led_task',['../task_8h.html#a92969f342424aecb6b28f38e700ab8c1',1,'task.h']]]
];
