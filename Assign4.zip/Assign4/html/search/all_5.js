var searchData=
[
  ['sampling_5ffreq_12',['sampling_freq',['../structRTDB.html#ab0d64d9dd97566fe25e85d1f1315a9a7',1,'RTDB']]],
  ['sensor_5ftask_13',['sensor_task',['../task_8h.html#a1b7b34cf2df2e7cbc173646975e494be',1,'task.h']]]
];
