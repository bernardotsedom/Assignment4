var searchData=
[
  ['sampling_5ffreq_31',['sampling_freq',['../structRTDB.html#ab0d64d9dd97566fe25e85d1f1315a9a7',1,'RTDB']]]
];
