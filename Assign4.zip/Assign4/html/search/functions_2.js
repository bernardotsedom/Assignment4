var searchData=
[
  ['sensor_5ftask_20',['sensor_task',['../task_8h.html#a1b7b34cf2df2e7cbc173646975e494be',1,'task.h']]]
];
