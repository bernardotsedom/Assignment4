var searchData=
[
  ['uart_5ftask_15',['uart_task',['../task_8h.html#a859d668e5cf9e7bef76f63be6fe614ff',1,'task.h']]]
];
