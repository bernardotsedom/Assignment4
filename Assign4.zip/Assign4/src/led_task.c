
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/drivers/adc.h>
#include <zephyr/sys/printk.h>
#include <hal/nrf_saadc.h>
#include <pthread.h>
#include <unistd.h>
#include "../include/task.h"


// Define os nós dos LEDs a partir do devicetree
#define LED0_NODE DT_ALIAS(led0)
#define LED1_NODE DT_ALIAS(led1)
#define LED2_NODE DT_ALIAS(led2)
#define LED3_NODE DT_ALIAS(led3)

// Define a especificação GPIO dos LEDs
static const struct gpio_dt_spec leds[] = {
    GPIO_DT_SPEC_GET(LED0_NODE, gpios),                                 // Especificação do LED 0
    GPIO_DT_SPEC_GET(LED1_NODE, gpios),                                 // Especificação do LED 1
    GPIO_DT_SPEC_GET(LED2_NODE, gpios),                                 // Especificação do LED 2
    GPIO_DT_SPEC_GET(LED3_NODE, gpios),                                 // Especificação do LED 3
};

// Função de tarefa dos LEDs
void led_task(void *arg1, void *arg2, void *arg3) {
    int ret = 0;

    // Verifica se os dispositivos dos LEDs estão prontos
    for (int i = 0; i < 4; i++) {
        if (!device_is_ready(leds[i].port)) {
            printk("LED %d device not ready\n", i);                     // Imprime uma mensagem de erro se o dispositivo não estiver pronto
            return;                                                     // Sai da função se algum LED não estiver pronto
        }
    }

    // Configura os pinos dos LEDs como saídas inativas
    for (int i = 0; i < 4; i++) {
        ret = gpio_pin_configure_dt(&leds[i], GPIO_OUTPUT_INACTIVE);    // Configura o pino do LED como saída inativa
        if (ret < 0) {
            printk("Failed to configure LED %d\n", i);                  // Imprime uma mensagem de erro se a configuração falhar
            return;                                                     // Sai da função se algum LED falhar na configuração
        }
    }

    // Loop infinito para atualizar o estado dos LEDs
    while (1) {
        k_mutex_lock(&rtdb_mutex, K_FOREVER);                           // Bloqueia o mutex para acessar a RTDB
        for (int i = 0; i < 4; i++) {
            gpio_pin_set_dt(&leds[i], rtdb.led_status[i]);              // Define o estado do LED de acordo com a RTDB
        }
        k_mutex_unlock(&rtdb_mutex);                                    // Desbloqueia o mutex
        k_sleep(K_MSEC(100));                                           // Aguarda 100 milissegundos antes da próxima verificação
    }
}