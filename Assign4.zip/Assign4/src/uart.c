#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/printk.h>
#include <string.h>
#include "../include/task.h"

// UART device and buffers
const struct device *uart_dev = DEVICE_DT_GET(DT_CHOSEN(zephyr_console));
#define UART_BUF_SIZE 128

static char uart_rx_buffer[UART_BUF_SIZE];
static size_t uart_buffer_idx = 0;

struct k_sem tx_sem;

// External variables for RTDB and its mutex
struct RTDB rtdb;
struct k_mutex rtdb_mutex;

// Function prototypes
void read_button_status(char *response);
void set_led_status(const char *cmd, char *response);
void read_analog_sensor(char *response);
void configure_board(const char *cmd, char *response);

// Function to send UART response synchronously
void uart_tx_sync(const char *message) {
    int ret = uart_tx(uart_dev, message, strlen(message), SYS_FOREVER_MS);
    if (ret == 0) {
        k_sem_take(&tx_sem, K_FOREVER); // Wait for transmission to complete
    } else {
        printk("Failed to send response via UART\n");
    }
}

// UART RX callback function
static void uart_cb(const struct device *dev, struct uart_event *evt, void *user_data) {
    switch (evt->type) {
        case UART_TX_DONE:
            k_sem_give(&tx_sem); // Signal that transmission is done
            break;
        case UART_RX_RDY:
            for (size_t i = 0; i < evt->data.rx.len; i++) {
                char c = evt->data.rx.buf[evt->data.rx.offset + i];
                if (c == '\r' || c == '\n') {
                    uart_rx_buffer[uart_buffer_idx] = '\0';
                    char response[UART_BUF_SIZE] = {0};  // Clear the response buffer
                    if (strncmp(uart_rx_buffer, "SL", 2) == 0) {
                        set_led_status(uart_rx_buffer, response);
                    } else if (strncmp(uart_rx_buffer, "BS", 2) == 0) {
                        read_button_status(response);
                    } else if (strncmp(uart_rx_buffer, "AS", 2) == 0) {
                        read_analog_sensor(response);
                    } else if (strncmp(uart_rx_buffer, "CONFIG", 6) == 0) {
                        configure_board(uart_rx_buffer, response);
                    } else {
                        snprintf(response, UART_BUF_SIZE, "UNKNOWN COMMAND\n");
                    }
                    uart_tx_sync(response);  // Send response synchronously
                    uart_buffer_idx = 0;
                } else if (uart_buffer_idx < UART_BUF_SIZE - 1) {
                    uart_rx_buffer[uart_buffer_idx++] = c;
                }
            }
            break;
        case UART_RX_DISABLED:
            uart_rx_enable(dev, uart_rx_buffer, sizeof(uart_rx_buffer), 100);
            break;
        default:
            break;
    }
}

void uart_task(void *arg1, void *arg2, void *arg3) {
    int err = 0;

    if (!device_is_ready(uart_dev)) {
        printk("UART device not ready\n");
        return;
    }

    k_sem_init(&tx_sem, 0, 1);  // Initialize the semaphore

    err = uart_callback_set(uart_dev, uart_cb, NULL);
    if (err) {
        printk("uart_callback_set() error. Error code:%d\n\r", err);
        return;
    }

    err = uart_rx_enable(uart_dev, uart_rx_buffer, sizeof(uart_rx_buffer), 100);

    while (1) {
        k_sleep(K_MSEC(100));  // Sleep for 100 milliseconds, adjust as needed
    }
}

void read_button_status(char *response) {
    k_mutex_lock(&rtdb_mutex, K_FOREVER);
    snprintf(response, UART_BUF_SIZE, "BUTTON STATUS: %d %d %d %d\n",
             rtdb.button_status[0], rtdb.button_status[1], rtdb.button_status[2], rtdb.button_status[3]);
    k_mutex_unlock(&rtdb_mutex);
}

void set_led_status(const char *cmd, char *response) {
    int led_index, led_status;
    if (sscanf(cmd, "SL %d %d", &led_index, &led_status) == 2) {
        if (led_index >= 0 && led_index < 4) {
            k_mutex_lock(&rtdb_mutex, K_FOREVER);
            rtdb.led_status[led_index] = led_status;
            k_mutex_unlock(&rtdb_mutex);
            snprintf(response, UART_BUF_SIZE, "LED %d SET TO %d\n", led_index, led_status);
        } else {
            snprintf(response, UART_BUF_SIZE, "INVALID LED INDEX\n");
        }
    } else {
        snprintf(response, UART_BUF_SIZE, "INVALID COMMAND FORMAT\n");
    }
}

void read_analog_sensor(char *response) {
    int adc_raw, adc_val;
    k_mutex_lock(&rtdb_mutex, K_FOREVER);
    adc_raw = rtdb.adc_raw;
    adc_val = rtdb.adc_val;
    k_mutex_unlock(&rtdb_mutex);
    snprintf(response, UART_BUF_SIZE, "ANALOG SENSOR: RAW=%d VAL=%d\n", adc_raw, adc_val);
}

void configure_board(const char *cmd, char *response) {
    int io_update_freq, sampling_freq, an_raw, an_val;
    if (sscanf(cmd, "CONFIGURE IO_UPDATE_FREQ=%d SAMPLING_FREQ=%d AN_RAW=%d AN_VAL=%d",
               &io_update_freq, &sampling_freq, &an_raw, &an_val) == 4) {
        k_mutex_lock(&rtdb_mutex, K_FOREVER);
        rtdb.io_update_freq = io_update_freq;
        rtdb.sampling_freq = sampling_freq;
        rtdb.an_raw = an_raw;
        rtdb.an_val = an_val;
        k_mutex_unlock(&rtdb_mutex);
        snprintf(response, UART_BUF_SIZE, "CONFIGURATION UPDATED\n");
    } else {
        snprintf(response, UART_BUF_SIZE, "INVALID CONFIGURATION FORMAT\n");
    }
}

void initialize_threads(void) {
    static struct k_thread thread_button;
    static struct k_thread thread_led;
    static struct k_thread thread_sensor;
    static struct k_thread thread_uart;

    static K_THREAD_STACK_DEFINE(stack_button, 1024);
    static K_THREAD_STACK_DEFINE(stack_led, 1024);
    static K_THREAD_STACK_DEFINE(stack_sensor, 1024);
    static K_THREAD_STACK_DEFINE(stack_uart, 1024);

    k_thread_create(&thread_button, stack_button, K_THREAD_STACK_SIZEOF(stack_button),
                    button_task, NULL, NULL, NULL, 1, 0, K_NO_WAIT);

    k_thread_create(&thread_led, stack_led, K_THREAD_STACK_SIZEOF(stack_led),
                    led_task, NULL, NULL, NULL, 1, 0, K_NO_WAIT);

    k_thread_create(&thread_sensor, stack_sensor, K_THREAD_STACK_SIZEOF(stack_sensor),
                    sensor_task, NULL, NULL, NULL, 1, 0, K_NO_WAIT);

    k_thread_create(&thread_uart, stack_uart, K_THREAD_STACK_SIZEOF(stack_uart),
                    uart_task, NULL, NULL, NULL, K_PRIO_COOP(7), 0, K_NO_WAIT);
}

void main(void) {
    k_mutex_init(&rtdb_mutex);
    initialize_threads();
}
