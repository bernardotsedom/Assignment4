#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/drivers/adc.h>
#include <zephyr/sys/printk.h>
#include <hal/nrf_saadc.h>
#include <pthread.h>
#include <unistd.h>
#include "../include/task.h"

//#define ADC_DEVICE_NAME DT_LABEL(DT_ALIAS(adcctrl))
#define ADC_NODE DT_NODELABEL(adc)                                          // Define o nó do dispositivo ADC a partir do devicetree
#define ADC_CHANNEL_ID 1                                                    // Define o ID do canal ADC a ser utilizado
#define ADC_RESOLUTION 10                                                   // Define a resolução do ADC (10 bits)

// Obtém o dispositivo ADC a partir do devicetree
static const struct device *adc_dev = DEVICE_DT_GET(ADC_NODE);
static int16_t sample_buffer;                                               // Buffer para armazenar a amostra do ADC

// Configuração do canal ADC
static const struct adc_channel_cfg channel_cfg = {
    .gain = ADC_GAIN_1,                                                     // Ganho do ADC
    .reference = ADC_REF_INTERNAL,                                          // Referência do ADC
    .acquisition_time = ADC_ACQ_TIME_DEFAULT,                               // Tempo de aquisição do ADC (padrão)
    .channel_id = ADC_CHANNEL_ID,                                           // ID do canal ADC
    .input_positive = NRF_SAADC_INPUT_AIN1,                                 // Entrada do canal ADC
};

// Função para inicializar o ADC
void init_adc(void) {
if (!device_is_ready(adc_dev)) {                                            // Verifica se o dispositivo ADC está pronto
        printk("ADC device not ready\n");                                   // Imprime mensagem de erro se o dispositivo não estiver pronto
        return;                                                             // Retorna se o dispositivo não estiver pronto
    }

    int err = adc_channel_setup(adc_dev, &channel_cfg);                     // Configura o canal ADC
    if (err) {                                                              // Verifica se houve erro na configuração do canal ADC
        printk("Failed to setup ADC channel: %d\n", err);                   // Imprime mensagem de erro
        return;                                                             // Retorna se houver erro na configuração
    }
}

// Função da tarefa do sensor
void sensor_task(void *arg1, void *arg2, void *arg3) {
    init_adc();                                                             // Inicializa o ADC

    // Sequência de amostragem do ADC
    const struct adc_sequence sequence = {
        .channels = BIT(ADC_CHANNEL_ID),                                    // Define o canal ADC a ser lido
        .buffer = &sample_buffer,                                           // Define o buffer para armazenar a amostra do ADC
        .buffer_size = sizeof(sample_buffer),                               // Define o tamanho do buffer de amostragem
        .resolution = ADC_RESOLUTION,                                       // Define a resolução do ADC
    };

    while (1) {                                                             // Loop infinito para leitura contínua do sensor
        int ret = adc_read(adc_dev, &sequence);                             // Lê a sequência do ADC
        if (ret < 0) {                                                      // Verifica se houve erro na leitura do ADC
            printk("ADC read error: %d\n", ret);                            // Imprime mensagem de erro
        } else {
            k_mutex_lock(&rtdb_mutex, K_FOREVER);                           // Bloqueia o mutex para acessar a RTDB
            rtdb.adc_raw = sample_buffer;                                   // Atualiza o valor raw do ADC na RTDB
            rtdb.adc_val = 60*(((double)sample_buffer / 1023.0) * 3.0)-60;  // Converte a amostra para temperatura
            k_mutex_unlock(&rtdb_mutex);                                    // Desbloqueia o mutex
        }

        k_sleep(K_SECONDS(1)); // Sleep durante 1 segundo antes da próxima leitura
    }
}


