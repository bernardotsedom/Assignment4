#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/drivers/adc.h>
#include <zephyr/sys/printk.h>
#include <hal/nrf_saadc.h>
#include <pthread.h>
#include <unistd.h>
#include "../include/task.h"

#define BUT0_NODE DT_ALIAS(sw0)                                                     // Define o nó do botão 0 a partir do devicetree
#define BUT1_NODE DT_ALIAS(sw1)                                                     // Define o nó do botão 1 a partir do devicetree
#define BUT2_NODE DT_ALIAS(sw2)                                                     // Define o nó do botão 2 a partir do devicetree
#define BUT3_NODE DT_ALIAS(sw3)                                                     // Define o nó do botão 3 a partir do devicetree

// Define a especificação GPIO dos botões
static const struct gpio_dt_spec buts[] = {
    GPIO_DT_SPEC_GET_OR(BUT0_NODE, gpios, {0}),                                     // Especificação do botão 0
    GPIO_DT_SPEC_GET_OR(BUT1_NODE, gpios, {0}),                                     // Especificação do botão 1
    GPIO_DT_SPEC_GET_OR(BUT2_NODE, gpios, {0}),                                     // Especificação do botão 2
    GPIO_DT_SPEC_GET_OR(BUT3_NODE, gpios, {0}),                                     // Especificação do botão 3
};

static struct gpio_callback button_cb_data[4];                                      // Estrutura para armazenar dados de callback dos botões

// Função de tarefa dos botões
void button_task(void *arg1, void *arg2, void *arg3) {
    int ret;

    // Verifica se os dispositivos dos botões estão prontos
    for (int i = 0; i < 4; i++) {
        if (!device_is_ready(buts[i].port)) {
            printk("Button %d device not ready\n", i);                              // Imprime uma mensagem de erro se o dispositivo não estiver ready
            return;
        }
    }

    // Configura os pinos dos botões e os callbacks de interrupção
    for (int i = 0; i < 4; i++) {
        ret = gpio_pin_configure_dt(&buts[i], GPIO_INPUT);                          // Configura o pino do botão como entrada
        if (ret < 0) {
            printk("Failed to configure button %d\n", i);                           // Imprime uma mensagem de erro se a configuração falhar
            return;
        }

        ret = gpio_pin_interrupt_configure_dt(&buts[i], GPIO_INT_EDGE_TO_ACTIVE);   // Configura a interrupção do pino do botão
        if (ret < 0) {
            printk("Failed to configure interrupt for button %d\n", i);             // Imprime uma mensagem de erro se a configuração da interrupção falhar
            return;
        }

        // Adiciona o callback do botão
        gpio_add_callback(buts[i].port, &button_cb_data[i]);
    }

    while (1) {                                                                     // Loop infinito para verificar o estado dos botões
        k_sleep(K_MSEC(100));                                                       // Espera um intervalo de tempo 

        k_mutex_lock(&rtdb_mutex, K_FOREVER);                                       // Bloqueia o mutex para acessar a RTDB
        for (int i = 0; i < 4; i++) {
            rtdb.button_status[i] = gpio_pin_get(buts[i].port, buts[i].pin);        // Obtém o estado do pino do botão e atualiza a RTDB
        }
        k_mutex_unlock(&rtdb_mutex);                                                // Desbloqueia o mutex
    }
}