#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/printk.h>
#include <string.h>
#include "../include/task.h"

// UART device and buffers
const struct device *uart_dev = DEVICE_DT_GET(DT_CHOSEN(zephyr_console));
#define UART_BUF_SIZE 128

static char uart_rx_buffer[UART_BUF_SIZE];
static size_t uart_buffer_idx = 0;


// External variables for RTDB and its mutex
struct RTDB rtdb;
struct k_mutex rtdb_mutex;

// Function prototypes
void read_button_status(char *response);
void set_led_status(const char *cmd, char *response);
void read_analog_sensor(char *response);
void configure_board(const char *cmd, char *response);
void uart_transmiter(const char *message);

// UART RX callback function
static void uart_cb(const struct device *dev, struct uart_event *evt, void *user_data) {
    switch (evt->type) {
        case UART_TX_DONE:
            break;
        case UART_RX_RDY:
            for (size_t i = 0; i < evt->data.rx.len; i++) {
                char c = evt->data.rx.buf[evt->data.rx.offset + i];
                if (c == '\r' || c == '\n') {
                    uart_rx_buffer[uart_buffer_idx] = '\0';
                    if (strncmp(uart_rx_buffer, "SL", 2) == 0) {
                        char response[UART_BUF_SIZE];
                        set_led_status(uart_rx_buffer, response);
                        uart_transmiter(response);
                    } else if (strncmp(uart_rx_buffer, "BS", 2) == 0) {
                        char response[UART_BUF_SIZE];
                        read_button_status(response);
                        uart_transmiter(response);
                    } else if (strncmp(uart_rx_buffer, "AS", 2) == 0) {
                        char response[UART_BUF_SIZE];
                        read_analog_sensor(response);
                        uart_transmiter(response);
                    } else if (strncmp(uart_rx_buffer, "CONFIG", 6) == 0) {
                        char response[UART_BUF_SIZE];
                        configure_board(uart_rx_buffer, response);
                        uart_transmiter(response);
                    } else {
                        uart_transmiter("UNKNOWN COMMAND\n");
                    }
                    uart_buffer_idx = 0;
                } else if (uart_buffer_idx < UART_BUF_SIZE - 1) {
                    uart_rx_buffer[uart_buffer_idx++] = c;
                }
            }
            break;
        case UART_RX_DISABLED:
            uart_rx_enable(dev, uart_rx_buffer, sizeof(uart_rx_buffer), SYS_FOREVER_MS);
            break;
        default:
            break;
    }
}

void uart_task(void *arg1, void *arg2, void *arg3) {
    int err = 0;

    if (!device_is_ready(uart_dev)) {
        printk("UART device not ready\n");
        return;
    }

    err = uart_callback_set(uart_dev, uart_cb, NULL);
    if (err) {
        printk("uart_callback_set() error. Error code:%d\n\r", err);
        return;
    }

    err = uart_rx_enable(uart_dev, uart_rx_buffer, sizeof(uart_rx_buffer),100);

    while (1) {
        k_sleep(K_MSEC(100));  // Sleep for 100 milliseconds, adjust as needed
    }
}

void uart_transmiter(const char *message) {
    
    uart_tx(uart_dev, message, strlen(message), 100);
}

void read_button_status(char *response) {
    k_mutex_lock(&rtdb_mutex, K_FOREVER);
    snprintf(response, UART_BUF_SIZE, "BUTTON STATUS: %d %d %d %d\n",
             rtdb.button_status[0], rtdb.button_status[1], rtdb.button_status[2], rtdb.button_status[3]);
    k_mutex_unlock(&rtdb_mutex);
}

void set_led_status(const char *cmd, char *response) {
    int led_index, led_status;
    if (sscanf(cmd, "SL %d %d", &led_index, &led_status) == 2) {
        if (led_index >= 0 && led_index < 4) {
            k_mutex_lock(&rtdb_mutex, K_FOREVER);
            rtdb.led_status[led_index] = led_status;
            k_mutex_unlock(&rtdb_mutex);
            snprintf(response, UART_BUF_SIZE, "LED %d SET TO %d\n", led_index, led_status);
        } else {
            snprintf(response, UART_BUF_SIZE, "INVALID LED INDEX\n");
        }
    } else {
        snprintf(response, UART_BUF_SIZE, "INVALID COMMAND FORMAT\n");
    }
}

void read_analog_sensor(char *response) {
    int adc_raw, adc_val;
    k_mutex_lock(&rtdb_mutex, K_FOREVER);
    adc_raw = rtdb.adc_raw;
    adc_val = rtdb.adc_val;
    k_mutex_unlock(&rtdb_mutex);
    snprintf(response, UART_BUF_SIZE, "ANALOG SENSOR: RAW=%d VAL=%d\n", adc_raw, adc_val);
}

void configure_board(const char *cmd, char *response) {
    int io_update_freq, sampling_freq, an_raw, an_val;
    if (sscanf(cmd, "CONFIGURE IO_UPDATE_FREQ=%d SAMPLING_FREQ=%d AN_RAW=%d AN_VAL=%d",
               &io_update_freq, &sampling_freq, &an_raw, &an_val) == 4) {
        k_mutex_lock(&rtdb_mutex, K_FOREVER);
        rtdb.io_update_freq = io_update_freq;
        rtdb.sampling_freq = sampling_freq;
        rtdb.an_raw = an_raw;
        rtdb.an_val = an_val;
        k_mutex_unlock(&rtdb_mutex);
        snprintf(response, UART_BUF_SIZE, "CONFIGURATION UPDATED\n");
    } else {
        snprintf(response, UART_BUF_SIZE, "INVALID CONFIGURATION FORMAT\n");
    }
}


