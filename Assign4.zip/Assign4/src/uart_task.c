#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/printk.h>
#include <string.h>
#include "../include/task.h"

// UART device and buffers
const struct device *uart_dev = DEVICE_DT_GET(DT_CHOSEN(zephyr_console)); // Obtém o dispositivo UART do devicetree
#define UART_BUF_SIZE 128 // Define o tamanho do buffer UART

static char uart_rx_buffer[UART_BUF_SIZE]; // Buffer de recepção UART
static size_t uart_buffer_idx = 0; // Índice do buffer UART

// Variáveis externas para RTDB e mutex
struct RTDB rtdb; // Estrutura da base de dados em tempo real
struct k_mutex rtdb_mutex; // Mutex para proteger o acesso à RTDB

// Funções
void read_button_status(char *response);
void set_led_status(const char *cmd, char *response);
void read_analog_sensor(char *response);
void configure_board(const char *cmd, char *response);
void uart_transmiter(const char *message);

// Função de callback de recepção UART
static void uart_cb(const struct device *dev, struct uart_event *evt, void *user_data) {
    switch (evt->type) {
        case UART_TX_DONE: // Evento de transmissão concluída
            break;
        case UART_RX_RDY: // Evento de recepção pronta
            for (size_t i = 0; i < evt->data.rx.len; i++) {
                char c = evt->data.rx.buf[evt->data.rx.offset + i]; // Lê o caractere recebido
                if (c == '\r' || c == '\n') { // Verifica se é o fim da linha
                    uart_rx_buffer[uart_buffer_idx] = '\0'; // Termina a string recebida
                    if (strncmp(uart_rx_buffer, "SL", 2) == 0) { // Verifica se o comando é "SL"
                        char response[UART_BUF_SIZE];
                        set_led_status(uart_rx_buffer, response); // Chama a função para definir o status do LED
                        uart_transmiter(response); // Transmite a resposta
                    } else if (strncmp(uart_rx_buffer, "BS", 2) == 0) { // Verifica se o comando é "BS"
                        char response[UART_BUF_SIZE];
                        read_button_status(response); // Chama a função para ler o status do botão
                        uart_transmiter(response); // Transmite a resposta
                    } else if (strncmp(uart_rx_buffer, "AS", 2) == 0) { // Verifica se o comando é "AS"
                        char response[UART_BUF_SIZE];
                        read_analog_sensor(response); // Chama a função para ler o sensor analógico
                        uart_transmiter(response); // Transmite a resposta
                    } else if (strncmp(uart_rx_buffer, "CONFIG", 6) == 0) { // Verifica se o comando é "CONFIG"
                        char response[UART_BUF_SIZE];
                        configure_board(uart_rx_buffer, response); // Chama a função para configurar a placa
                        uart_transmiter(response); // Transmite a resposta
                    } else {
                        uart_transmiter("UNKNOWN COMMAND\n"); // Comando desconhecido
                    }
                    uart_buffer_idx = 0; // Reseta o índice do buffer
                } else if (uart_buffer_idx < UART_BUF_SIZE - 1) { // Adiciona o caractere ao buffer se não estiver cheio
                    uart_rx_buffer[uart_buffer_idx++] = c;
                }
            }
            break;
        case UART_RX_DISABLED: // Evento de recepção desabilitada
            uart_rx_enable(dev, uart_rx_buffer, sizeof(uart_rx_buffer), SYS_FOREVER_MS); // Reabilita a recepção UART
            break;
        default:
            break;
    }
}

// Tarefa UART
void uart_task(void *arg1, void *arg2, void *arg3) {
    int err = 0;

    if (!device_is_ready(uart_dev)) {
        printk("UART device not ready\n"); // Verifica se o dispositivo UART está pronto
        return;
    }

    err = uart_callback_set(uart_dev, uart_cb, NULL); // Configura a função de callback UART
    if (err) {
        printk("uart_callback_set() error. Error code:%d\n\r", err); // Erro ao configurar o callback UART
        return;
    }

    err = uart_rx_enable(uart_dev, uart_rx_buffer, sizeof(uart_rx_buffer), 100); // Habilita a recepção UART

    while (1) {
        k_sleep(K_MSEC(100));  // sleep durante 100 milissegundos
    }
}

// Função para transmitir dados via UART
void uart_transmiter(const char *message) {
    uart_tx(uart_dev, message, strlen(message), 100); // Transmite a mensagem via UART
}

// Função para ler o status dos botões
void read_button_status(char *response) {
    k_mutex_lock(&rtdb_mutex, K_FOREVER); // Bloqueia o mutex
    snprintf(response, UART_BUF_SIZE, "BUTTON STATUS: %d %d %d %d\n",
             rtdb.button_status[0], rtdb.button_status[1], rtdb.button_status[2], rtdb.button_status[3]);
    k_mutex_unlock(&rtdb_mutex); // Desbloqueia o mutex
}

// Função para definir o status dos LEDs
void set_led_status(const char *cmd, char *response) {
    int led_index, led_status;
    if (sscanf(cmd, "SL %d %d", &led_index, &led_status) == 2) {
        if (led_index >= 0 && led_index < 4) {
            k_mutex_lock(&rtdb_mutex, K_FOREVER);
            rtdb.led_status[led_index] = led_status; // Atualiza o status do LED na RTDB
            k_mutex_unlock(&rtdb_mutex);
            snprintf(response, UART_BUF_SIZE, "LED %d SET TO %d\n", led_index, led_status);
        } else {
            snprintf(response, UART_BUF_SIZE, "INVALID LED INDEX\n"); // Índice de LED inválido
        }
    } else {
        snprintf(response, UART_BUF_SIZE, "INVALID COMMAND FORMAT\n"); // Formato de comando inválido
    }
}

// Função para ler o valor do sensor analógico
void read_analog_sensor(char *response) {
    int adc_raw, adc_val;
    k_mutex_lock(&rtdb_mutex, K_FOREVER);
    adc_raw = rtdb.adc_raw; // Lê o valor raw do ADC
    adc_val = rtdb.adc_val; // Lê o valor do ADC processado
    k_mutex_unlock(&rtdb_mutex);
    snprintf(response, UART_BUF_SIZE, "ANALOG SENSOR: RAW=%d VAL=%d\n", adc_raw, adc_val);
}

// Função para configurar a placa
void configure_board(const char *cmd, char *response) {
    int io_update_freq, sampling_freq, an_raw, an_val;
    if (sscanf(cmd, "CONFIGURE IO_UPDATE_FREQ=%d SAMPLING_FREQ=%d AN_RAW=%d AN_VAL=%d",
               &io_update_freq, &sampling_freq, &an_raw, &an_val) == 4) {
        k_mutex_lock(&rtdb_mutex, K_FOREVER);
        rtdb.io_update_freq = io_update_freq; // Atualiza a frequência de atualização de IO na RTDB
        rtdb.sampling_freq = sampling_freq; // Atualiza a frequência de amostragem na RTDB
        rtdb.an_raw = an_raw; // Atualiza o valor raw do ADC na RTDB
        rtdb.an_val = an_val; // Atualiza o valor do ADC processado na RTDB
        k_mutex_unlock(&rtdb_mutex);
        snprintf(response, UART_BUF_SIZE, "CONFIGURATION UPDATED\n");
    } else {
        snprintf(response, UART_BUF_SIZE, "INVALID CONFIGURATION FORMAT\n"); // Formato de configuração inválido
    }
}
