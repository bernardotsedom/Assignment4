// Função para inicializar as threads
void initialize_threads(void) {
    // Declaração das threads
    static struct k_thread thread_button;
    static struct k_thread thread_led;
    static struct k_thread thread_sensor;
    static struct k_thread thread_uart;

    // Definição da stack para cada thread
    static K_THREAD_STACK_DEFINE(stack_button, 1024); // 1024 bytes para a thread botão
    static K_THREAD_STACK_DEFINE(stack_led, 1024);    // 1024 bytes para a thread LED
    static K_THREAD_STACK_DEFINE(stack_sensor, 1024); // 1024 bytes para a thread sensor
    static K_THREAD_STACK_DEFINE(stack_uart, 1024);   // 1024 bytes para a thread UART

    // Criação da thread do botão com prioridade 2
    k_thread_create(&thread_button, stack_button, K_THREAD_STACK_SIZEOF(stack_button),
                    button_task, NULL, NULL, NULL, 2, 0, K_NO_WAIT);

    // Criação da thread do LED com prioridade 3
    k_thread_create(&thread_led, stack_led, K_THREAD_STACK_SIZEOF(stack_led),
                    led_task, NULL, NULL, NULL, 3, 0, K_NO_WAIT);

    // Criação da thread do sensor com prioridade 4
    k_thread_create(&thread_sensor, stack_sensor, K_THREAD_STACK_SIZEOF(stack_sensor),
                    sensor_task, NULL, NULL, NULL, 4, 0, K_NO_WAIT);

    // Criação da thread do UART com prioridade 1
    k_thread_create(&thread_uart, stack_uart, K_THREAD_STACK_SIZEOF(stack_uart),
                    uart_task, NULL, NULL, NULL, 1, 0, K_NO_WAIT);
}

// Função principal
void main(void) {
k_mutex_init(&rtdb_mutex);                              // Inicializa o mutex para proteger a RTDB
initialize_threads();                                   // Inicializa as threads
    return;                                             // Termina a função principal
}