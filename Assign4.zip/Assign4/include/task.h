/**
 * @file tasks.h
 * @brief Header file for task functions and RTDB structure.
 * @authors     
 *          - João Modesto, 97943
 *          - Luis Araujo, 93287
 * 
 * This file contains the declarations for the Real-Time Database (RTDB) structure and task functions 
 * for button, LED, sensor, and UART operations. It also includes necessary includes for Zephyr and device handling.
 */

#ifndef TASKS_H
#define TASKS_H

#include <zephyr/kernel.h>          
#include <zephyr/device.h>        
#include <zephyr/devicetree.h>      
#include <zephyr/drivers/gpio.h>   
#include <zephyr/drivers/uart.h>    
#include <zephyr/drivers/adc.h>     
#include <zephyr/sys/printk.h>      
#include <hal/nrf_saadc.h>          
#include <pthread.h>                
#include <unistd.h>                 

/**
 * @struct RTDB
 * @brief Real-Time Database structure.
 *
 * This structure holds the current state of the buttons, LEDs, and ADC values. It is used to share
 * data between different tasks in a thread-safe manner.
 */
struct RTDB {
    uint8_t button_status[4]; ///< Status of buttons (pressed or not)
    uint8_t led_status[4];    ///< Status of LEDs (on or off)
    uint16_t adc_raw;         ///< Raw ADC value
    float adc_val;            ///< Processed ADC value in a specific domain

    int io_update_freq;       ///< Frequency of I/O update
    int sampling_freq;        ///< Frequency of analog input sampling
    int an_raw;               ///< Raw analog input value
    int an_val;               ///< Processed analog input value
};

extern struct RTDB rtdb;      ///< Global instance of RTDB
extern struct k_mutex rtdb_mutex; ///< Mutex for protecting access to RTDB

/**
 * @brief Task function for handling button inputs.
 *
 * This function configures the GPIO pins for buttons, sets up interrupts, and continuously updates
 * the RTDB with the current button status.
 *
 * @param arg1 Unused.
 * @param arg2 Unused.
 * @param arg3 Unused.
 */
void button_task(void *arg1, void *arg2, void *arg3);

/**
 * @brief Task function for controlling LEDs.
 *
 * This function configures the GPIO pins for LEDs and continuously updates the LED states based on
 * the values in the RTDB.
 *
 * @param arg1 Unused.
 * @param arg2 Unused.
 * @param arg3 Unused.
 */
void led_task(void *arg1, void *arg2, void *arg3);

/**
 * @brief Task function for handling sensor inputs.
 *
 * This function initializes the ADC, reads sensor values at specified intervals, and updates the
 * RTDB with the raw and processed ADC values.
 *
 * @param arg1 Unused.
 * @param arg2 Unused.
 * @param arg3 Unused.
 */
void sensor_task(void *arg1, void *arg2, void *arg3);

/**
 * @brief Task function for handling UART communication.
 *
 * This function sets up the UART interface, processes incoming commands, and sends responses. It
 * allows interaction with the RTDB and configuration of operational parameters.
 *
 * @param arg1 Unused.
 * @param arg2 Unused.
 * @param arg3 Unused.
 */
void uart_task(void *arg1, void *arg2, void *arg3);

#endif // TASKS_H
